#!/bin/bash

# Dossier local pour les pages man
MAN_DIR="$HOME/.local/share/man/man1"
mkdir -p "$MAN_DIR"

# Liste des fichiers à traiter
FILES=("add-dhcp-client.1" "list-dhcp.1" "remove-dhcp-client.1" "check-dhcp.1" "dhcpsup.1")

echo "Installation des pages man dans $MAN_DIR..."

for file in "${FILES[@]}"; do
    if [ -f "$file" ]; then
        gzip -f "$file"
        cp "${file}.gz" "$MAN_DIR/"
        echo "→ Installé : $file"
    else
        echo "⚠️  Fichier introuvable : $file"
    fi
done

# Mise à jour du MANPATH si nécessaire
PROFILE_FILE="$HOME/.bashrc"
if ! grep -q 'MANPATH=.*.local' "$PROFILE_FILE"; then
    echo 'export MANPATH="$HOME/.local/share/man:$MANPATH"' >> "$PROFILE_FILE"
    echo "✅ MANPATH ajouté à $PROFILE_FILE (relance ton terminal ou fais 'source ~/.bashrc')"
fi

echo "✅ Installation terminée."
