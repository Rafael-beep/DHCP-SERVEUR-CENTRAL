# Spécifie l'interpréteur Python à utiliser pour exécuter ce script
#!/usr/bin/env python3
# Nom du script
# add-dhcp-client.py

# Importe les modules nécessaires
import sys  # Module pour accéder aux arguments de la ligne de commande
import dhcp  # Module personnalisé pour les opérations liées au DHCP
import config  # Module personnalisé pour charger et manipuler la configuration

# Fonction pour ajouter un client DHCP
def ajout_client(ip, mac):
    """
    Ajoute un client DHCP en associant l'adresse MAC à l'adresse IP spécifiée.
    
    :param ip: Adresse IP à attribuer au client
    :param mac: Adresse MAC du client
    """
    # Charge la configuration à partir du fichier superviseur_conf.yml
    cfg = config.load_config("/home/sae203/dhcp/superviseur_conf.yml")
    
    # Récupère les informations du serveur DHCP responsable de l'IP spécifiée
    dhcp_server = config.get_dhcp_server(ip, cfg)

    # Vérifie si un serveur DHCP a été trouvé pour l'IP spécifiée
    if dhcp_server is None:
        # Si aucun serveur DHCP n'est trouvé, affiche une erreur et quitte la fonction
        print("Erreur : IP invalide ou non couverte par un serveur DHCP.")
        return

    # Extrait l'adresse IP du serveur DHCP (supposé être la première clé du dictionnaire)
    ip_dhcp = list(dhcp_server.keys())[0]
    # Récupère le chemin du fichier de configuration des hôtes DHCP
    fichier_config = cfg["dhcp_hosts_cfg"]

    # Crée une ligne de configuration DHCP pour associer l'adresse MAC à l'IP
    ligne = f'dhcp-host={mac},{ip}'
    # Ajoute cette ligne au fichier de configuration du serveur DHCP spécifié
    dhcp.ajouter_ligne(ip_dhcp, fichier_config, ligne)
    # Affiche un message de confirmation
    print(f"Client a bien été ajouté : {mac} -> {ip} sur {ip_dhcp}")

# Fonction principale exécutée lorsque le script est lancé directement
def main():
    """
    Point d'entrée principal du script.
    """
    # Vérifie si le nombre d'arguments de la ligne de commande est correct
    if len(sys.argv) != 3:
        # Si les arguments sont incorrects, affiche l'utilisation et quitte
        print("Utilisation : pour l'instant (mais bientôt ./) python3 add-dhcp-client.py <MAC> <IP>")
        return

    # Extrait les arguments de la ligne de commande : adresse MAC et IP
    mac = sys.argv[1]
    ip = sys.argv[2]
    # Appelle la fonction pour ajouter le client DHCP
    ajout_client(ip, mac)

# Vérifie si le script est exécuté directement (et non importé comme un module)
if __name__ == "__main__":
    # Exécute la fonction principale
    main()
