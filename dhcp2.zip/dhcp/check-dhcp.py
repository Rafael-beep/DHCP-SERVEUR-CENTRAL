#!/usr/bin/env python3
# check-dhcp.py

import sys
import dhcp           # Module personnalisé pour la connexion SSH
import config as cfg   # Fichier de configuration contenant les IPs et chemins
import re              # Module pour les expressions régulières

def detecter_doublons(dhcp_ip, chemin_config, utilisateur):
    # Récupère le contenu du fichier de configuration DHCP via SSH
    lignes_config = dhcp.connection_ssh(dhcp_ip, f"cat {chemin_config}")
    lignes = str(lignes_config).strip().split("\n")

    # Listes pour suivre les adresses MAC et IP déjà vues
    adresses_mac_vues = []
    adresses_ip_vues = []

    # Listes pour stocker les doublons trouvés
    mac_dupliquees = []
    ip_dupliquees = []

    # Parcours des lignes pour extraire les adresses MAC et IP
    for ligne in lignes:
        mac_match = re.search(r"([0-9a-fA-F]{2}:){5}[0-9a-fA-F]{2}", ligne)
        ip_match = re.search(r"(\d{1,3}\.){3}\d{1,3}", ligne)

        if mac_match:
            mac = mac_match.group()
            if mac not in adresses_mac_vues:
                adresses_mac_vues.append(mac)
            else:
                mac_dupliquees.append(mac)

        if ip_match:
            ip = ip_match.group()
            if ip not in adresses_ip_vues:
                adresses_ip_vues.append(ip)
            else:
                ip_dupliquees.append(ip)

    # Recherche dans le fichier les lignes contenant les IP en double
    lignes_ip_dupliquees = []
    for ip in ip_dupliquees:
        resultat = dhcp.connection_ssh(dhcp_ip, f"grep '{ip}' {chemin_config}")
        lignes_ip_dupliquees += str(resultat).strip().split("\n")

    # Recherche dans le fichier les lignes contenant les MAC en double
    lignes_mac_dupliquees = []
    for mac in mac_dupliquees:
        resultat = dhcp.connection_ssh(dhcp_ip, f"grep '{mac}' {chemin_config}")
        lignes_mac_dupliquees += str(resultat).strip().split("\n")

    # Affichage des doublons d’IP trouvés
    if ip_dupliquees:
        print(f"Le serveur DHCP {dhcp_ip} contient des IP en double :")
        for ligne in lignes_ip_dupliquees:
            print(ligne)
        print()

    # Affichage des doublons de MAC trouvés
    if mac_dupliquees:
        print(f"Le serveur DHCP {dhcp_ip} contient des adresses MAC en double :")
        for ligne in lignes_mac_dupliquees:
            print(ligne)
        print()

def lancer_verification():
    # Cas où aucun argument n'est fourni : on vérifie tous les serveurs depuis config_simple
    if len(sys.argv) == 1:
        serveurs, fichier_conf, utilisateur = cfg.config_simple()
        for serveur in serveurs:
            detecter_doublons(serveur, fichier_conf, utilisateur)
    # Cas où un seul argument est fourni : on vérifie un seul serveur avec une config spécifique
    elif len(sys.argv) == 2:
        serveur, fichier_conf, utilisateur = cfg.conf1(sys.argv[1])
        detecter_doublons(serveur, fichier_conf, utilisateur)
    # Cas où plus d’un argument est fourni : erreur
    else:
        print("Erreur : nombre d'arguments invalide.")

# Point d'entrée du script
if __name__ == "__main__":
    lancer_verification()

