# config.py
import yaml
import os
import sys
import ipaddress

def load_config(filename, create=False):
    if os.path.exists(filename):
        try:
            with open(filename, "r") as f:
                return yaml.safe_load(f)
        except yaml.YAMLError as e:
            print(f"Erreur de chargement YAML : {e}")
            sys.exit(1)
    elif create:
        default_cfg = {
            "dhcp_hosts_cfg": "/etc/dnsmasq.d/hosts.conf",
            "user": "sae203"
        }
        with open(filename, "w") as f:
            yaml.dump(default_cfg, f)
        return default_cfg
    else:
        print(f"Fichier de configuration {filename} introuvable.")
        sys.exit(1)

def get_dhcp_server(ip, cfg):
    try:
        ip_addr = ipaddress.ip_address(ip)
    except ValueError:
        return None

    for server, network in cfg.get("dhcp-servers", {}).items():
        if ip_addr in ipaddress.ip_network(network):
            return {server: network}
    return None

def config_simple():
    # Charger la configuration à partir d'un fichier YAML ou utiliser des valeurs par défaut
    cfg = load_config("/home/sae203/dhcp/superviseur_conf.yml")
    serveurs_dhcp = ["10.20.1.5", "10.20.2.5"]  # ou extraire ceci de la configuration
    fichier_conf = cfg.get("dhcp_hosts_cfg", "/etc/dnsmasq.d/hosts.conf")
    utilisateur = cfg.get("user", "sae203")
    return serveurs_dhcp, fichier_conf, utilisateur
