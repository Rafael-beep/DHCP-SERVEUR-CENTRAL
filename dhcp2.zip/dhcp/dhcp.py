# dhcp.py

from fabric import Connection         # Utilisé pour les connexions SSH
import config                         # Module de configuration
import ipaddress                      # Pas utilisé ici, mais permet de manipuler des adresses IP
import paramiko                      # Utilisé pour la clé privée SSH
import sys
import re
import yaml                          # Pas utilisé ici non plus

# Chemin vers la clé SSH privée
key_path = "/home/sae203/.ssh/id_rsa"
SSH_USER = "sae203"
# SSH_PASSWORD = "sae203"  # Commenté : pas utilisé (authentification par clé)
SUDO_PASSWORD = "sae203"

# Chargement de la clé privée
pkey = paramiko.RSAKey.from_private_key_file(key_path)

# Fonction de connexion SSH avec clé privée
def _connect(server):
    return Connection(host=server, user=SSH_USER, connect_kwargs={"pkey": pkey})

# Exécute une commande SSH sur un hôte et retourne la sortie
def connection_ssh(hote, commande):
    result = _connect(hote).run(commande, hide=True)
    return result.stdout.strip()

# Liste les couples MAC/IP dans le fichier de configuration DHCP
def dhcp_list(server, cfg):
    chemin = cfg["dhcp_hosts_cfg"]
    sortie = connection_ssh(server, f"grep 'dhcp-host' {chemin} || true")
    liste = []
    for ligne in sortie.splitlines():
        try:
            parts = ligne.split("=")[1].split(",")
            if len(parts) == 2:
                liste.append({"mac": parts[0], "ip": parts[1]})
        except IndexError:
            continue
    return liste

# Vérifie si une adresse MAC existe déjà dans le fichier de configuration
def mac_exists(cnx, mac, cfg):
    chemin = cfg["dhcp_hosts_cfg"]
    sortie = cnx.run(f"grep '{mac}' {chemin} || true", hide=True).stdout.strip()
    return bool(sortie)

# Vérifie si une IP est déjà associée à une autre MAC
def ip_other_mac_exists(cnx, ip, mac, cfg):
    chemin = cfg["dhcp_hosts_cfg"]
    sortie = cnx.run(f"grep '{ip}' {chemin} || true", hide=True).stdout.strip()
    for ligne in sortie.splitlines():
        if mac not in ligne:
            return True
    return False

# Ajoute une réservation DHCP (mac, ip) au serveur
def dhcp_add(ip, mac, server, cfg):
    cnx = _connect(server)
    chemin = cfg["dhcp_hosts_cfg"]
    
    # Vérifie si l'IP est déjà utilisée par une autre MAC
    if ip_other_mac_exists(cnx, ip, mac, cfg):
        print(f"Erreur : IP {ip} déjà utilisée par une autre adresse MAC.")
        return False

    # Récupère le fichier de config actuel
    contenu = connection_ssh(server, f"cat {chemin} || true")
    nouvelle_ligne = f"dhcp-host={mac},{ip}"
    nouvelles_lignes = []

    ligne_existe = False
    # Remplace ou ajoute la ligne correspondant à la MAC
    for ligne in contenu.splitlines():
        if mac in ligne:
            nouvelles_lignes.append(nouvelle_ligne)
            ligne_existe = True
        else:
            nouvelles_lignes.append(ligne)

    if not ligne_existe:
        nouvelles_lignes.append(nouvelle_ligne)

    # Écrit le nouveau fichier et redémarre le service
    ecraser_fichier(server, chemin, "\n".join(nouvelles_lignes))
    redemarrer_service(server)
    return True

# Supprime une réservation DHCP à partir d'une MAC
def dhcp_remove(mac, server, cfg):
    cnx = _connect(server)
    chemin = cfg["dhcp_hosts_cfg"]
    contenu = connection_ssh(server, f"cat {chemin} || true")
    nouvelles_lignes = [ligne for ligne in contenu.splitlines() if mac not in ligne]

    # Si aucune ligne n'est supprimée, la MAC n'existe pas
    if len(nouvelles_lignes) == len(contenu.splitlines()):
        print(f"Erreur : adresse MAC {mac} introuvable.")
        return False

    ecraser_fichier(server, chemin, "\n".join(nouvelles_lignes))
    redemarrer_service(server)
    return True

# Ajoute une ligne à la fin d’un fichier de configuration si elle n’existe pas déjà
def ajouter_ligne(hote, chemin, ligne):
    contenu = connection_ssh(hote, f"cat {chemin} || true")
    if ligne in contenu:
        return
    contenu += "\n" + ligne
    ecraser_fichier(hote, chemin, contenu)
    redemarrer_service(hote)

# Remplace complètement un fichier de configuration distant
def ecraser_fichier(hote, chemin, contenu):
    c = _connect(hote)
    tmp = "/tmp/tmp_reservations.conf"
    with open("/tmp/local_tmp_reservations.conf", "w") as f:
        f.write(contenu)
    c.put("/tmp/local_tmp_reservations.conf", tmp)
    c.sudo(f"mv {tmp} {chemin}", hide=True, pty=False)

# Redémarre le service dnsmasq pour appliquer les changements DHCP
def redemarrer_service(hote):
    c = _connect(hote)
    c.sudo("systemctl restart dnsmasq", hide=True, pty=False)

