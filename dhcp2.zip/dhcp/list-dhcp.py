#!/usr/bin/env python3

import sys
import yaml           # Utilisé pour lire le fichier YAML de configuration
import dhcp           # Module personnalisé pour interagir avec le serveur DHCP

# Chemin du fichier de configuration YAML contenant les IPs et chemins
FICHIER_YAML = "/home/sae203/dhcp/superviseur_conf.yml"

# Charge la configuration depuis le fichier YAML
def charger_config():
    with open(FICHIER_YAML, "r") as f:
        return yaml.safe_load(f)

# Liste les associations MAC/IP dans le fichier de conf du serveur DHCP donné
def lister_associations(ip_srv, fichier_cfg):
    # Récupère le contenu du fichier DHCP à distance via SSH
    contenu = dhcp.connection_ssh(ip_srv, f"cat {fichier_cfg}")
    
    # Filtre uniquement les lignes de type 'dhcp-host='
    lignes = [l.strip() for l in contenu.splitlines() if l.startswith("dhcp-host=")]

    associations = []
    for ligne in lignes:
        try:
            # On enlève le préfixe puis on extrait la MAC et l'IP
            data = ligne.replace("dhcp-host=", "")
            mac, ip = data.split(",")
            mac = mac.strip().lower()
            ip = ip.strip()
            associations.append((mac, ip))
        except ValueError:
            continue  # Ignore les lignes mal formées
    return associations

# Affiche les associations trouvées pour un serveur donné
def afficher_associations(ip_srv, fichier_cfg):
    associations = lister_associations(ip_srv, fichier_cfg)
    
    # Si un seul serveur est passé en argument, n’affiche pas son IP avant la liste
    if len(sys.argv) == 2:
        for mac, ip in associations:
            print(f"{mac}\t\t{ip}")
    else:
        # Affichage avec nom du serveur en préfixe si on fait une liste globale
        print(f"{ip_srv}:")
        for mac, ip in associations:
            print(f"{mac}\t\t{ip}")

# Fonction principale
def main():
    cfg = charger_config()
    fichier_cfg = cfg['dhcp_hosts_cfg']

    if len(sys.argv) == 2:
        # Cas où un seul serveur est passé en argument
        ip_srv = sys.argv[1]
        if ip_srv not in cfg['dhcp-servers']:
            print("Erreur : serveur DHCP non reconnu dans la configuration", file=sys.stderr)
            sys.exit(1)
        afficher_associations(ip_srv, fichier_cfg)
    else:
        # Cas où aucun argument n'est donné : on liste tous les serveurs
        for ip_srv in cfg['dhcp-servers'].keys():
            afficher_associations(ip_srv, fichier_cfg)
            print()

# Lancement du programme
if __name__ == "__main__":
    main()
