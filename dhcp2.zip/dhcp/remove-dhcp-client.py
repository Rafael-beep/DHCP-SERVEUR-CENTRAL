#!/usr/bin/env python3

import re
import sys
import dhcp  # Module personnalisé pour interactions SSH et fichiers DHCP

# Liste des IPs des serveurs DHCP à vérifier
SERVEURS_DHCP = ["10.20.1.5", "10.20.2.5"]

# Chemin du fichier de configuration contenant les réservations DHCP
FICHIER_CONFIG = "/etc/dnsmasq.d/dhcp-hosts.conf"

# Vérifie si l'adresse MAC est valide (format XX:XX:XX:XX:XX:XX)
def est_mac_valide(mac):
    return re.match(r'^([0-9A-Fa-f]{2}:){5}[0-9A-Fa-f]{2}$', mac) is not None

# Supprime une réservation DHCP correspondant à la MAC spécifiée
def remove_client(mac):
    trouve = False  # Permet de savoir si la MAC a été trouvée au moins une fois

    for ip_dhcp in SERVEURS_DHCP:
        # Récupère le contenu du fichier DHCP à distance
        contenu = dhcp.connection_ssh(ip_dhcp, f"cat {FICHIER_CONFIG}")
        lignes = contenu.splitlines()

        nouvelles_lignes = []
        ligne_supprimee = False  # Flag pour savoir si une ligne a été supprimée sur ce serveur

        # Parcours de chaque ligne du fichier pour chercher une correspondance
        for ligne in lignes:
            if ligne.startswith("dhcp-host=") and mac.lower() in ligne.lower():
                # Extraction de la MAC dans la ligne
                mac_extrait = ligne.split('=')[1].split(',')[0].lower()
                # On compare précisément avec la MAC donnée
                if mac_extrait == mac.lower():
                    ligne_supprimee = True
                    trouve = True
                    continue  # On ne garde pas cette ligne (elle est supprimée)
            nouvelles_lignes.append(ligne)  # Ligne conservée

        # Si une ligne a été supprimée, on met à jour le fichier sur le serveur
        if ligne_supprimee:
            contenu_modifie = "\n".join(nouvelles_lignes) + "\n"
            dhcp.ecraser_fichier(ip_dhcp, FICHIER_CONFIG, contenu_modifie)
            dhcp.redemarrer_service(ip_dhcp)
            print(f"MAC {mac} supprimée de {ip_dhcp}")
            return  # Fin de la fonction après suppression

    # Si la MAC n’a été trouvée sur aucun serveur
    if not trouve:
        print("MAC address not found", file=sys.stderr)

# Point d'entrée principal du script
def main():
    if len(sys.argv) != 2:
        print("Usage: delete-dhcp-client.py MAC", file=sys.stderr)
        sys.exit(1)

    mac = sys.argv[1]
    if not est_mac_valide(mac):
        print("error: bad MAC address.", file=sys.stderr)
        sys.exit(1)

    remove_client(mac)

# Lancement du script
if __name__ == "__main__":
    main()

